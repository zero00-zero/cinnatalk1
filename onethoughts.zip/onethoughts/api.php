<?php
// Set response headers
header('Content-Type: application/json; charset=utf-8');

// Disable direct error printing in response JSON (keeps response clean)
ini_set('display_errors', 0);
error_reporting(E_ALL);

// Enable session
session_start();

require_once 'dbh1.php';

// Verify database connection status
if (!isset($conn) || $conn->connect_error) {
    http_response_code(500);
    echo json_encode(['error' => 'Database connection failed']);
    exit;
}

$route = $_GET['_route'] ?? '';
$route_parts = explode('/', trim($route, '/'));
$data = json_decode(file_get_contents('php://input'), true) ?? [];

// Helper function to return JSON response
function json_resp($data_array, $status_code = 200) {
    http_response_code($status_code);
    echo json_encode($data_array);
    exit;
}

if (count($route_parts) > 0 && $route_parts[0] !== '') {
    $resource = $route_parts[0];
    
    // 1. GET /api/me
    if ($resource === 'me' && $_SERVER['REQUEST_METHOD'] === 'GET') {
        if (!isset($_SESSION['user_id'])) {
            json_resp(['logged_in' => false], 401);
        }
        $user_id = $_SESSION['user_id'];
        $stmt = $conn->prepare("SELECT id, username, display_name, profile_pic, theme FROM users WHERE id = ?");
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $user = $stmt->get_result()->fetch_assoc();
        if (!$user) {
            unset($_SESSION['user_id']);
            json_resp(['logged_in' => false], 401);
        }
        json_resp([
            'logged_in' => true,
            'user' => [
                'id' => (int)$user['id'],
                'username' => $user['username'],
                'display_name' => $user['display_name'],
                'profile_pic' => $user['profile_pic'],
                'theme' => $user['theme']
            ]
        ]);
    }
    
    // 2. POST /api/register
    elseif ($resource === 'register' && $_SERVER['REQUEST_METHOD'] === 'POST') {
        $username = trim(strtolower($data['username'] ?? ''));
        $password = $data['password'] ?? '';
        $display_name = trim($data['display_name'] ?? '');

        if (empty($username) || empty($password) || empty($display_name)) {
            json_resp(['error' => 'Please fill in all fields'], 400);
        }
        if (strlen($username) < 3) {
            json_resp(['error' => 'Username must be at least 3 characters long'], 400);
        }
        if (strlen($password) < 5) {
            json_resp(['error' => 'Password must be at least 5 characters long'], 400);
        }

        $stmt = $conn->prepare("SELECT id FROM users WHERE username = ?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        if ($stmt->get_result()->fetch_assoc()) {
            json_resp(['error' => 'Username is already taken'], 400);
        }

        $password_hash = password_hash($password, PASSWORD_BCRYPT);
        $stmt = $conn->prepare("INSERT INTO users (username, password_hash, display_name) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $username, $password_hash, $display_name);
        if ($stmt->execute()) {
            $user_id = $conn->insert_id;
            $_SESSION['user_id'] = $user_id;
            json_resp([
                'success' => true,
                'user' => [
                    'id' => $user_id,
                    'username' => $username,
                    'display_name' => $display_name,
                    'profile_pic' => null,
                    'theme' => 'pastel-blue'
                ]
            ]);
        } else {
            json_resp(['error' => 'An error occurred during registration'], 500);
        }
    }
    
    // 3. POST /api/login
    elseif ($resource === 'login' && $_SERVER['REQUEST_METHOD'] === 'POST') {
        $username = trim(strtolower($data['username'] ?? ''));
        $password = $data['password'] ?? '';

        if (empty($username) || empty($password)) {
            json_resp(['error' => 'Please fill in all fields'], 400);
        }

        $stmt = $conn->prepare("SELECT * FROM users WHERE username = ?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $user = $stmt->get_result()->fetch_assoc();

        if (!$user || !password_verify($password, $user['password_hash'])) {
            json_resp(['error' => 'Invalid username or password'], 400);
        }

        $_SESSION['user_id'] = $user['id'];
        json_resp([
            'success' => true,
            'user' => [
                'id' => (int)$user['id'],
                'username' => $user['username'],
                'display_name' => $user['display_name'],
                'profile_pic' => $user['profile_pic'],
                'theme' => $user['theme']
            ]
        ]);
    }
    
    // 4. POST /api/logout
    elseif ($resource === 'logout' && $_SERVER['REQUEST_METHOD'] === 'POST') {
        unset($_SESSION['user_id']);
        session_destroy();
        json_resp(['success' => true]);
    }
    
    // 5. Profile Routes
    elseif ($resource === 'profile') {
        if (!isset($_SESSION['user_id'])) {
            json_resp(['error' => 'Unauthorized'], 401);
        }
        $user_id = $_SESSION['user_id'];
        
        // 5a. POST /api/profile/avatar
        if (count($route_parts) > 1 && $route_parts[1] === 'avatar' && $_SERVER['REQUEST_METHOD'] === 'POST') {
            if (!isset($_FILES['avatar'])) {
                json_resp(['error' => 'No file uploaded'], 400);
            }
            $file = $_FILES['avatar'];
            if ($file['error'] !== UPLOAD_ERR_OK || empty($file['name'])) {
                json_resp(['error' => 'No file selected'], 400);
            }

            $allowed_extensions = ['png', 'jpg', 'jpeg', 'gif'];
            $file_ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
            if (!in_array($file_ext, $allowed_extensions)) {
                json_resp(['error' => 'Allowed image types are png, jpg, jpeg, gif'], 400);
            }

            $upload_dir = 'uploads';
            if (!is_dir($upload_dir)) {
                mkdir($upload_dir, 0755, true);
            }

            $new_filename = 'user_' . $user_id . '_' . time() . '.' . $file_ext;
            $dest_path = $upload_dir . '/' . $new_filename;

            if (move_uploaded_file($file['tmp_name'], $dest_path)) {
                $db_path = 'uploads/' . $new_filename;
                $stmt = $conn->prepare("UPDATE users SET profile_pic = ? WHERE id = ?");
                $stmt->bind_param("si", $db_path, $user_id);
                if ($stmt->execute()) {
                    json_resp([
                        'success' => true,
                        'profile_pic' => $db_path
                    ]);
                } else {
                    json_resp(['error' => 'Failed to update avatar in database'], 500);
                }
            } else {
                json_resp(['error' => 'Failed to save uploaded image'], 500);
            }
        }
        // 5b. POST /api/profile
        elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $new_username = trim(strtolower($data['username'] ?? ''));
            $new_display_name = trim($data['display_name'] ?? '');
            $new_theme = trim($data['theme'] ?? '');

            if (empty($new_username) || empty($new_display_name)) {
                json_resp(['error' => 'Username and Name cannot be empty'], 400);
            }
            if (strlen($new_username) < 3) {
                json_resp(['error' => 'Username must be at least 3 characters long'], 400);
            }

            $valid_themes = ['pastel-blue', 'pastel-pink', 'pastel-lavender', 'pastel-mint', 'pastel-peach'];
            if (!empty($new_theme) && !in_array($new_theme, $valid_themes)) {
                json_resp(['error' => 'Invalid pastel theme choice'], 400);
            }

            $stmt = $conn->prepare("SELECT id FROM users WHERE username = ? AND id != ?");
            $stmt->bind_param("si", $new_username, $user_id);
            $stmt->execute();
            if ($stmt->get_result()->fetch_assoc()) {
                json_resp(['error' => 'Username is already taken'], 400);
            }

            if (empty($new_theme)) {
                $stmt = $conn->prepare("SELECT theme FROM users WHERE id = ?");
                $stmt->bind_param("i", $user_id);
                $stmt->execute();
                $res = $stmt->get_result()->fetch_assoc();
                $new_theme = $res['theme'] ?? 'pastel-blue';
            }

            $stmt = $conn->prepare("UPDATE users SET username = ?, display_name = ?, theme = ? WHERE id = ?");
            $stmt->bind_param("sssi", $new_username, $new_display_name, $new_theme, $user_id);
            if ($stmt->execute()) {
                json_resp([
                    'success' => true,
                    'user' => [
                        'id' => $user_id,
                        'username' => $new_username,
                        'display_name' => $new_display_name,
                        'theme' => $new_theme
                    ]
                ]);
            } else {
                json_resp(['error' => 'Failed to update profile'], 500);
            }
        }
    }
    
    // 6. Messages Routes
    elseif ($resource === 'messages') {
        if (!isset($_SESSION['user_id'])) {
            json_resp(['error' => 'Unauthorized'], 401);
        }
        $user_id = $_SESSION['user_id'];

        // 6a. GET /api/messages
        if (count($route_parts) === 1 && $_SERVER['REQUEST_METHOD'] === 'GET') {
            $stmt = $conn->prepare("SELECT id, content, reply, timestamp FROM messages WHERE recipient_id = ? ORDER BY timestamp DESC");
            $stmt->bind_param("i", $user_id);
            $stmt->execute();
            $res = $stmt->get_result();

            $messages = [];
            while ($row = $res->fetch_assoc()) {
                $messages[] = [
                    'id' => (int)$row['id'],
                    'content' => $row['content'],
                    'reply' => $row['reply'],
                    'timestamp' => $row['timestamp']
                ];
            }
            json_resp(['messages' => $messages]);
        }
        // 6b. DELETE /api/messages/<id>
        elseif (count($route_parts) === 2 && $_SERVER['REQUEST_METHOD'] === 'DELETE') {
            $msg_id = (int)$route_parts[1];
            
            $stmt = $conn->prepare("SELECT id FROM messages WHERE id = ? AND recipient_id = ?");
            $stmt->bind_param("ii", $msg_id, $user_id);
            $stmt->execute();
            if (!$stmt->get_result()->fetch_assoc()) {
                json_resp(['error' => 'Message not found or access denied'], 404);
            }

            $stmt = $conn->prepare("DELETE FROM messages WHERE id = ?");
            $stmt->bind_param("i", $msg_id);
            if ($stmt->execute()) {
                json_resp(['success' => true]);
            } else {
                json_resp(['error' => 'Failed to delete message'], 500);
            }
        }
        // 6c. POST /api/messages/<id>/reply
        elseif (count($route_parts) === 3 && $route_parts[2] === 'reply' && $_SERVER['REQUEST_METHOD'] === 'POST') {
            $msg_id = (int)$route_parts[1];
            $reply_content = trim($data['reply'] ?? '');

            if (strlen($reply_content) > 500) {
                json_resp(['error' => 'Reply exceeds 500 characters limit'], 400);
            }

            $stmt = $conn->prepare("SELECT id FROM messages WHERE id = ? AND recipient_id = ?");
            $stmt->bind_param("ii", $msg_id, $user_id);
            $stmt->execute();
            if (!$stmt->get_result()->fetch_assoc()) {
                json_resp(['error' => 'Message not found or access denied'], 404);
            }

            $reply_val = empty($reply_content) ? null : $reply_content;
            $stmt = $conn->prepare("UPDATE messages SET reply = ? WHERE id = ?");
            $stmt->bind_param("si", $reply_val, $msg_id);
            if ($stmt->execute()) {
                json_resp(['success' => true]);
            } else {
                json_resp(['error' => 'Failed to save reply'], 500);
            }
        }
    }
    
    // 7. GET /api/user/<username>
    elseif ($resource === 'user' && count($route_parts) === 2 && $_SERVER['REQUEST_METHOD'] === 'GET') {
        $username = trim(strtolower($route_parts[1]));

        $stmt = $conn->prepare("SELECT id, username, display_name, profile_pic, theme FROM users WHERE username = ?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $user = $stmt->get_result()->fetch_assoc();

        if (!$user) {
            json_resp(['error' => 'User not found'], 404);
        }

        $stmt = $conn->prepare("SELECT content, reply, timestamp FROM messages WHERE recipient_id = ? AND reply IS NOT NULL AND reply != '' ORDER BY timestamp DESC");
        $stmt->bind_param("i", $user['id']);
        $stmt->execute();
        $res = $stmt->get_result();

        $answers = [];
        while ($row = $res->fetch_assoc()) {
            $answers[] = [
                'content' => $row['content'],
                'reply' => $row['reply'],
                'timestamp' => $row['timestamp']
            ];
        }

        json_resp([
            'username' => $user['username'],
            'display_name' => $user['display_name'],
            'profile_pic' => $user['profile_pic'],
            'theme' => $user['theme'],
            'answers' => $answers
        ]);
    }
    
    // 8. POST /api/send_message
    elseif ($resource === 'send_message' && $_SERVER['REQUEST_METHOD'] === 'POST') {
        $username = trim(strtolower($data['username'] ?? ''));
        $content = trim($data['content'] ?? '');

        if (empty($username) || empty($content)) {
            json_resp(['error' => 'Recipient and message content are required'], 400);
        }
        if (strlen($content) > 500) {
            json_resp(['error' => 'Message exceeds 500 characters limit'], 400);
        }

        $stmt = $conn->prepare("SELECT id FROM users WHERE username = ?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $user = $stmt->get_result()->fetch_assoc();

        if (!$user) {
            json_resp(['error' => 'Recipient user not found'], 404);
        }

        $stmt = $conn->prepare("INSERT INTO messages (recipient_id, content) VALUES (?, ?)");
        $stmt->bind_param("is", $user['id'], $content);
        if ($stmt->execute()) {
            json_resp(['success' => true]);
        } else {
            json_resp(['error' => 'Failed to send message'], 500);
        }
    }
}

// Default 404
json_resp(['error' => 'Endpoint not found'], 404);
