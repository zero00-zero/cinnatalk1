// Current active user details
let currentUser = null;
let inboxMessages = [];

// Page initialization
document.addEventListener('DOMContentLoaded', () => {
    // Check initial auth state
    checkAuth();

    // Listen for hash changes to route pages
    window.addEventListener('hashchange', router);
});

// ROUTER SYSTEM FOR SPA
async function router() {
    const hash = window.location.hash;
    const allViews = document.querySelectorAll('.view');
    
    // Hide all views first
    allViews.forEach(v => v.classList.remove('active'));

    // Handle Route: Send Message
    if (hash.startsWith('#send/')) {
        const username = hash.split('/')[1];
        if (username) {
            setupSendView(username);
            return;
        }
    }

    // Handle Route: Dashboard
    if (hash === '#dashboard') {
        if (!currentUser) {
            // Check auth first
            const loggedIn = await checkAuth();
            if (!loggedIn) {
                window.location.hash = '';
                return;
            }
        }
        setupDashboardView();
        return;
    }

    // Handle Default: Landing (Login / Register)
    if (!hash || hash === '#login' || hash === '#register') {
        if (currentUser) {
            window.location.hash = '#dashboard';
            return;
        }
        setupLandingView();
    }
}

// 1. LANDING VIEW SETUP
function setupLandingView() {
    document.getElementById('landing-view').classList.add('active');
    document.body.className = 'pastel-blue'; // Default landing theme
    
    // Check which subtab to show based on hash
    const hash = window.location.hash;
    if (hash === '#register') {
        switchAuthTab('register');
    } else {
        switchAuthTab('login');
    }
}

function switchAuthTab(tab) {
    const loginForm = document.getElementById('login-form');
    const regForm = document.getElementById('register-form');
    const loginTab = document.getElementById('tab-login');
    const regTab = document.getElementById('tab-register');
    const alertBox = document.getElementById('auth-alert');
    
    alertBox.classList.add('hidden');

    if (tab === 'login') {
        loginForm.classList.remove('hidden');
        regForm.classList.add('hidden');
        loginTab.classList.add('active');
        regTab.classList.remove('active');
        window.location.hash = '#login';
    } else {
        loginForm.classList.add('hidden');
        regForm.classList.remove('hidden');
        loginTab.classList.remove('active');
        regTab.classList.add('active');
        window.location.hash = '#register';
    }
}

// 2. DASHBOARD VIEW SETUP
function setupDashboardView() {
    document.getElementById('dashboard-view').classList.add('active');
    
    // Apply user theme preference
    if (currentUser && currentUser.theme) {
        document.body.className = currentUser.theme;
        
        // Check the radio button corresponding to user theme
        const radio = document.querySelector(`input[name="theme-pref"][value="${currentUser.theme}"]`);
        if (radio) radio.checked = true;
    }

    // Populate user text fields
    document.getElementById('welcome-title').innerText = `Hi, ${currentUser.display_name}! ☁️`;
    document.getElementById('profile-name').value = currentUser.display_name;
    document.getElementById('profile-username').value = currentUser.username;
    
    // Setup share link
    const shareLink = `${window.location.origin}${window.location.pathname}#send/${currentUser.username}`;
    document.getElementById('my-share-link').value = shareLink;

    // Load profile photo preview
    updateAvatarUI(currentUser.profile_pic);

    // Fetch inbox messages
    loadInboxMessages();
}

// 3. SEND MESSAGE VIEW SETUP
async function setupSendView(recipientUsername) {
    const sendView = document.getElementById('send-view');
    sendView.classList.add('active');
    
    const sendAlert = document.getElementById('send-alert');
    sendAlert.classList.add('hidden');
    
    // Clear send form
    document.getElementById('message-content').value = '';
    document.getElementById('char-counter').innerText = '0 / 500';

    try {
        const response = await fetch(`/api/user/${recipientUsername}`);
        if (!response.ok) {
            showSendAlert('User not found. Check the username in the link!', 'error');
            return;
        }

        const data = await response.json();
        
        // Dynamically apply recipient's custom theme to make the page personalized!
        document.body.className = data.theme || 'pastel-blue';
        
        // Populate recipient badge details
        document.getElementById('recipient-display-name').innerText = data.display_name;
        document.getElementById('recipient-username-val').innerText = data.username;
        
        const avatarImg = document.getElementById('recipient-avatar');
        if (data.profile_pic) {
            avatarImg.src = data.profile_pic;
        } else {
            avatarImg.src = `https://api.dicebear.com/7.x/adventurer/svg?seed=${data.username}&backgroundColor=b6d7f9`;
        }

        // Populate Q&A Board details
        document.getElementById('board-username').innerText = data.username;
        const qaList = document.getElementById('public-answers-list');
        const answers = data.answers || [];
        
        if (answers.length === 0) {
            qaList.innerHTML = `
                <div class="empty-state" style="height: 100px;">
                    <p>No public Q&As yet... ☁️</p>
                </div>
            `;
        } else {
            qaList.innerHTML = '';
            answers.forEach(qa => {
                const dateStr = formatDate(qa.timestamp);
                const qaDiv = document.createElement('div');
                qaDiv.className = 'qa-pair';
                qaDiv.innerHTML = `
                    <div class="qa-question">
                        <div class="qa-question-header">
                            <span>Anonymous Note 🤫</span>
                            <span>${dateStr}</span>
                        </div>
                        <div class="qa-question-text">${escapeHTML(qa.content)}</div>
                    </div>
                    <div class="qa-answer">
                        <div class="qa-answer-header">
                            ☁️ <span>${escapeHTML(data.display_name)} replied:</span>
                        </div>
                        <div class="qa-answer-text">${escapeHTML(qa.reply)}</div>
                    </div>
                `;
                qaList.appendChild(qaDiv);
            });
        }

    } catch (err) {
        showSendAlert('Failed to load recipient details.', 'error');
        console.error(err);
    }
}

// THEME SELECTION INTERACTIVE PREVIEW
function previewTheme(themeName) {
    document.body.className = themeName;
}

// AUTH HANDLERS
async function handleLogin(e) {
    e.preventDefault();
    const alertBox = document.getElementById('auth-alert');
    alertBox.classList.add('hidden');

    const username = document.getElementById('login-username').value;
    const password = document.getElementById('login-password').value;

    try {
        const response = await fetch('/api/login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username, password })
        });
        const data = await response.json();

        if (response.ok && data.success) {
            currentUser = data.user;
            window.location.hash = '#dashboard';
        } else {
            showAuthAlert(data.error || 'Login failed.', 'error');
        }
    } catch (err) {
        showAuthAlert('Network error during login.', 'error');
        console.error(err);
    }
}

async function handleRegister(e) {
    e.preventDefault();
    const alertBox = document.getElementById('auth-alert');
    alertBox.classList.add('hidden');

    const name = document.getElementById('reg-name').value;
    const username = document.getElementById('reg-username').value;
    const password = document.getElementById('reg-password').value;

    // Frontend validation
    const usernameRegex = /^[a-zA-Z0-9_]+$/;
    if (!usernameRegex.test(username)) {
        showAuthAlert('Username can only contain letters, numbers, and underscores.', 'error');
        return;
    }

    try {
        const response = await fetch('/api/register', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ 
                display_name: name, 
                username: username, 
                password: password 
            })
        });
        const data = await response.json();

        if (response.ok && data.success) {
            currentUser = data.user;
            window.location.hash = '#dashboard';
        } else {
            showAuthAlert(data.error || 'Registration failed.', 'error');
        }
    } catch (err) {
        showAuthAlert('Network error during registration.', 'error');
        console.error(err);
    }
}

async function handleLogout() {
    try {
        await fetch('/api/logout', { method: 'POST' });
        currentUser = null;
        window.location.hash = '#login';
    } catch (err) {
        console.error('Logout error:', err);
    }
}

// PROFILE HANDLERS
async function handleProfileUpdate(e) {
    e.preventDefault();
    const alertBox = document.getElementById('profile-alert');
    alertBox.classList.add('hidden');

    const displayName = document.getElementById('profile-name').value;
    const username = document.getElementById('profile-username').value;
    const themePref = document.querySelector('input[name="theme-pref"]:checked').value;

    try {
        const response = await fetch('/api/profile', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                display_name: displayName,
                username: username,
                theme: themePref
            })
        });
        const data = await response.json();

        if (response.ok && data.success) {
            currentUser.display_name = data.user.display_name;
            currentUser.username = data.user.username;
            currentUser.theme = data.user.theme;
            
            // Re-apply theme and UI
            document.body.className = currentUser.theme;
            document.getElementById('welcome-title').innerText = `Hi, ${currentUser.display_name}! ☁️`;
            const shareLink = `${window.location.origin}${window.location.pathname}#send/${currentUser.username}`;
            document.getElementById('my-share-link').value = shareLink;
            
            showProfileAlert('Profile updated successfully!', 'success');
        } else {
            showProfileAlert(data.error || 'Failed to update profile.', 'error');
        }
    } catch (err) {
        showProfileAlert('Network error while updating profile.', 'error');
        console.error(err);
    }
}

// PROFILE PICTURE AVATAR UPLOAD
async function handleAvatarUpload(e) {
    const file = e.target.files[0];
    if (!file) return;

    const alertBox = document.getElementById('profile-alert');
    alertBox.classList.add('hidden');

    const formData = new FormData();
    formData.append('avatar', file);

    try {
        const response = await fetch('/api/profile/avatar', {
            method: 'POST',
            body: formData
        });
        const data = await response.json();

        if (response.ok && data.success) {
            currentUser.profile_pic = data.profile_pic;
            // Update preview with a cache-busting timestamp query parameter
            updateAvatarUI(data.profile_pic);
            showProfileAlert('Profile picture updated!', 'success');
        } else {
            showProfileAlert(data.error || 'Failed to upload photo.', 'error');
        }
    } catch (err) {
        showProfileAlert('Network error while uploading photo.', 'error');
        console.error(err);
    }
}

function updateAvatarUI(profilePicPath) {
    const preview = document.getElementById('profile-avatar-preview');
    if (profilePicPath) {
        // Appending timestamp forces the browser to bypass its image cache and reload the new avatar immediately
        preview.src = `${profilePicPath}?t=${Date.now()}`;
    } else {
        preview.src = `https://api.dicebear.com/7.x/adventurer/svg?seed=${currentUser.username}&backgroundColor=b6d7f9`;
    }
}

// INBOX MESSAGE HANDLERS
async function loadInboxMessages() {
    const listContainer = document.getElementById('messages-list-container');
    const msgCountTag = document.getElementById('msg-count-tag');

    try {
        const response = await fetch('/api/messages');
        if (!response.ok) throw new Error('Unauthorized');
        
        const data = await response.json();
        const messages = data.messages || [];
        inboxMessages = messages;

        // Update counts
        msgCountTag.innerText = `${messages.length} message${messages.length === 1 ? '' : 's'}`;

        if (messages.length === 0) {
            listContainer.innerHTML = `
                <div class="empty-state">
                    <span class="empty-state-mascot">☁️</span>
                    <p>Your inbox is empty. Share your link to get sweet anonymous notes!</p>
                </div>
            `;
            return;
        }

        // Render messages
        listContainer.innerHTML = '';
        messages.forEach(msg => {
            const dateStr = formatDate(msg.timestamp);
            const hasReply = msg.reply && msg.reply.trim() !== '';
            const replyBadge = hasReply ? `<span class="reply-indicator-tag">Replied 🌸</span>` : '';
            
            const msgCard = document.createElement('div');
            msgCard.className = 'message-bubble clickable';
            msgCard.innerHTML = `
                <div class="message-meta">
                    <span class="message-time">☁️ ${dateStr} ${replyBadge}</span>
                    <button class="delete-msg-btn" title="Delete note">🗑️</button>
                </div>
                <div class="message-content">${escapeHTML(msg.content)}</div>
            `;
            
            // Click handler to open inspection modal
            msgCard.addEventListener('click', (e) => {
                if (e.target.closest('.delete-msg-btn')) {
                    e.stopPropagation();
                    deleteMessage(msg.id);
                    return;
                }
                openMessageModal(msg.id);
            });
            
            listContainer.appendChild(msgCard);
        });

    } catch (err) {
        listContainer.innerHTML = `
            <div class="empty-state">
                <p>Failed to load inbox. Please try logging in again.</p>
            </div>
        `;
        console.error(err);
    }
}

async function deleteMessage(msgId) {
    if (!confirm('Are you sure you want to delete this sweet message forever? ☁️')) return;

    try {
        const response = await fetch(`/api/messages/${msgId}`, {
            method: 'DELETE'
        });
        const data = await response.json();

        if (response.ok && data.success) {
            loadInboxMessages();
        } else {
            alert(data.error || 'Failed to delete message.');
        }
    } catch (err) {
        console.error('Error deleting message:', err);
    }
}

// SENDING ANONYMOUS MESSAGE
async function handleSendMessage(e) {
    e.preventDefault();
    const sendAlert = document.getElementById('send-alert');
    sendAlert.classList.add('hidden');

    const recipientUsername = document.getElementById('recipient-username-val').innerText;
    const content = document.getElementById('message-content').value.trim();

    if (!content) return;

    try {
        const response = await fetch('/api/send_message', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                username: recipientUsername,
                content: content
            })
        });
        const data = await response.json();

        if (response.ok && data.success) {
            // Open sweet success modal
            document.getElementById('success-modal').classList.remove('hidden');
            document.getElementById('message-content').value = '';
            document.getElementById('char-counter').innerText = '0 / 500';
        } else {
            showSendAlert(data.error || 'Could not send message.', 'error');
        }
    } catch (err) {
        showSendAlert('Network error occurred.', 'error');
        console.error(err);
    }
}

function closeSuccessModal() {
    document.getElementById('success-modal').classList.add('hidden');
}

// HELPER FUNCTIONS
async function checkAuth() {
    try {
        const response = await fetch('/api/me');
        if (response.ok) {
            const data = await response.json();
            if (data.logged_in) {
                currentUser = data.user;
                router();
                return true;
            }
        }
    } catch (e) {
        console.error('Auth verification failed', e);
    }
    currentUser = null;
    router();
    return false;
}

function copyShareLink() {
    const copyText = document.getElementById('my-share-link');
    copyText.select();
    copyText.setSelectionRange(0, 99999); // Mobile compatibility

    navigator.clipboard.writeText(copyText.value)
        .then(() => {
            const btn = document.getElementById('btn-copy-link');
            const originalText = btn.innerText;
            btn.innerText = 'Copied! 💕';
            btn.classList.add('success');
            setTimeout(() => {
                btn.innerText = originalText;
                btn.classList.remove('success');
            }, 2000);
        })
        .catch(err => {
            console.error('Could not copy link: ', err);
        });
}

function updateCharCount() {
    const text = document.getElementById('message-content').value;
    const counter = document.getElementById('char-counter');
    counter.innerText = `${text.length} / 500`;
}

// Alert Boxes helpers
function showAuthAlert(msg, type) {
    const alertBox = document.getElementById('auth-alert');
    alertBox.innerText = msg;
    alertBox.className = `alert-box ${type}`;
    alertBox.classList.remove('hidden');
}

function showProfileAlert(msg, type) {
    const alertBox = document.getElementById('profile-alert');
    alertBox.innerText = msg;
    alertBox.className = `alert-box ${type}`;
    alertBox.classList.remove('hidden');
    // Auto hide profile alert after 4 seconds
    setTimeout(() => {
        alertBox.classList.add('hidden');
    }, 4000);
}

function showSendAlert(msg, type) {
    const alertBox = document.getElementById('send-alert');
    alertBox.innerText = msg;
    alertBox.className = `alert-box ${type}`;
    alertBox.classList.remove('hidden');
}

// Date formatter
function formatDate(timestampStr) {
    // SQLite timestamps default to UTC: 'YYYY-MM-DD HH:MM:SS'
    // Let's parse and make a readable string.
    try {
        // Replace space with T to make it ISO format
        const isoStr = timestampStr.replace(' ', 'T') + 'Z';
        const date = new Date(isoStr);
        
        // Check valid date
        if (isNaN(date.getTime())) return timestampStr;
        
        const options = { 
            month: 'short', 
            day: 'numeric', 
            hour: '2-digit', 
            minute: '2-digit' 
        };
        return date.toLocaleDateString(undefined, options);
    } catch (e) {
        return timestampStr;
    }
}

// Basic HTML escaping for security
function escapeHTML(str) {
    return str
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#039;');
}

// DETAIL MODAL & REPLY OPERATIONS
function openMessageModal(msgId) {
    const msg = inboxMessages.find(m => m.id === msgId);
    if (!msg) return;

    document.getElementById('detail-message-id').value = msg.id;
    document.getElementById('detail-message-time').innerText = `☁️ ${formatDate(msg.timestamp)}`;
    document.getElementById('detail-message-text').innerText = msg.content;
    
    const replyText = msg.reply || '';
    document.getElementById('reply-content').value = replyText;
    document.getElementById('reply-char-counter').innerText = `${replyText.length} / 500`;
    
    document.getElementById('detail-alert').classList.add('hidden');
    document.getElementById('message-detail-modal').classList.remove('hidden');
}

function closeDetailModal() {
    document.getElementById('message-detail-modal').classList.add('hidden');
}

function updateReplyCharCount() {
    const text = document.getElementById('reply-content').value;
    const counter = document.getElementById('reply-char-counter');
    counter.innerText = `${text.length} / 500`;
}

async function handleSaveReply(e) {
    e.preventDefault();
    const alertBox = document.getElementById('detail-alert');
    alertBox.classList.add('hidden');

    const msgId = document.getElementById('detail-message-id').value;
    const replyText = document.getElementById('reply-content').value.trim();

    try {
        const response = await fetch(`/api/messages/${msgId}/reply`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ reply: replyText })
        });
        const data = await response.json();

        if (response.ok && data.success) {
            // Update locally
            const msg = inboxMessages.find(m => m.id === parseInt(msgId));
            if (msg) msg.reply = replyText;
            
            // Refresh list and close
            loadInboxMessages();
            closeDetailModal();
        } else {
            alertBox.innerText = data.error || 'Failed to save reply.';
            alertBox.className = 'alert-box error';
            alertBox.classList.remove('hidden');
        }
    } catch (err) {
        alertBox.innerText = 'Network error saving reply.';
        alertBox.className = 'alert-box error';
        alertBox.classList.remove('hidden');
        console.error(err);
    }
}

async function handleDeleteFromDetail() {
    const msgId = document.getElementById('detail-message-id').value;
    if (!msgId) return;

    if (confirm('Are you sure you want to delete this sweet message forever? ☁️')) {
        try {
            const response = await fetch(`/api/messages/${msgId}`, {
                method: 'DELETE'
            });
            const data = await response.json();

            if (response.ok && data.success) {
                closeDetailModal();
                loadInboxMessages();
            } else {
                alert(data.error || 'Failed to delete message.');
            }
        } catch (err) {
            console.error('Error deleting message:', err);
        }
    }
}
