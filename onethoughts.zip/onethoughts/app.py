import os
import pymysql
import re
from flask import Flask, request, jsonify, session, send_from_directory
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
import time

app = Flask(__name__, static_folder='static', static_url_path='')
app.secret_key = 'cinnamoroll-cotton-candy-secret-key-9988'

UPLOAD_FOLDER = os.path.join('static', 'uploads')
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif'}

# Ensure upload directory exists
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

# Parse database configuration from dbh1.php
def load_php_config(filepath='dbh1.php'):
    config = {}
    if os.path.exists(filepath):
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                content = f.read()
            pattern = re.compile(r'\$(\w+)\s*=\s*["\'](.*?)["\']\s*;')
            for match in pattern.finditer(content):
                var_name, val = match.groups()
                config[var_name] = val
        except Exception as e:
            print(f"Warning: Failed to parse {filepath}: {e}")
    return config

db_config = load_php_config()

def get_db():
    conn = pymysql.connect(
        host=db_config.get('server', 'localhost'),
        user=db_config.get('username'),
        password=db_config.get('password'),
        database=db_config.get('dbname'),
        cursorclass=pymysql.cursors.DictCursor,
        charset='utf8mb4',
        connect_timeout=5
    )
    return conn

def init_db():
    try:
        conn = get_db()
        cursor = conn.cursor()
        # Create users table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS users (
                id INT AUTO_INCREMENT PRIMARY KEY,
                username VARCHAR(255) UNIQUE NOT NULL,
                password_hash VARCHAR(255) NOT NULL,
                display_name VARCHAR(255) NOT NULL,
                profile_pic VARCHAR(255),
                theme VARCHAR(50) DEFAULT 'pastel-blue'
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        ''')
        # Create messages table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS messages (
                id INT AUTO_INCREMENT PRIMARY KEY,
                recipient_id INT NOT NULL,
                content TEXT NOT NULL,
                reply TEXT,
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (recipient_id) REFERENCES users(id) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        ''')
        conn.commit()
        
        # Migration: Add reply column if table already exists without it
        try:
            cursor.execute('ALTER TABLE messages ADD COLUMN reply TEXT')
            conn.commit()
        except Exception:
            pass
            
        conn.close()
    except Exception as e:
        print(f"Warning: Could not connect or initialize MySQL at startup: {e}")

init_db()

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@app.route('/')
def index():
    return app.send_static_file('index.html')

# API: Register
@app.route('/api/register', methods=['POST'])
def register():
    data = request.get_json() or {}
    username = data.get('username', '').strip().lower()
    password = data.get('password', '')
    display_name = data.get('display_name', '').strip()

    if not username or not password or not display_name:
        return jsonify({'error': 'Please fill in all fields'}), 400

    if len(username) < 3:
        return jsonify({'error': 'Username must be at least 3 characters long'}), 400
    
    if len(password) < 5:
        return jsonify({'error': 'Password must be at least 5 characters long'}), 400

    conn = get_db()
    cursor = conn.cursor()
    
    # Check if username exists
    cursor.execute('SELECT id FROM users WHERE username = %s', (username,))
    if cursor.fetchone():
        conn.close()
        return jsonify({'error': 'Username is already taken'}), 400

    password_hash = generate_password_hash(password)
    
    try:
        cursor.execute(
            'INSERT INTO users (username, password_hash, display_name) VALUES (%s, %s, %s)',
            (username, password_hash, display_name)
        )
        conn.commit()
        user_id = cursor.lastrowid
        
        # Log the user in
        session['user_id'] = user_id
        
        conn.close()
        return jsonify({
            'success': True,
            'user': {
                'id': user_id,
                'username': username,
                'display_name': display_name,
                'profile_pic': None,
                'theme': 'pastel-blue'
            }
        })
    except Exception as e:
        conn.close()
        return jsonify({'error': 'An error occurred during registration'}), 500

# API: Login
@app.route('/api/login', methods=['POST'])
def login():
    data = request.get_json() or {}
    username = data.get('username', '').strip().lower()
    password = data.get('password', '')

    if not username or not password:
        return jsonify({'error': 'Please fill in all fields'}), 400

    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM users WHERE username = %s', (username,))
    user = cursor.fetchone()
    conn.close()

    if not user or not check_password_hash(user['password_hash'], password):
        return jsonify({'error': 'Invalid username or password'}), 400

    session['user_id'] = user['id']
    
    return jsonify({
        'success': True,
        'user': {
            'id': user['id'],
            'username': user['username'],
            'display_name': user['display_name'],
            'profile_pic': user['profile_pic'],
            'theme': user['theme']
        }
    })

# API: Logout
@app.route('/api/logout', methods=['POST'])
def logout():
    session.pop('user_id', None)
    return jsonify({'success': True})

# API: Get Current User
@app.route('/api/me', methods=['GET'])
def me():
    user_id = session.get('user_id')
    if not user_id:
        return jsonify({'logged_in': False}), 401

    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('SELECT id, username, display_name, profile_pic, theme FROM users WHERE id = %s', (user_id,))
    user = cursor.fetchone()
    conn.close()

    if not user:
        session.pop('user_id', None)
        return jsonify({'logged_in': False}), 401

    return jsonify({
        'logged_in': True,
        'user': {
            'id': user['id'],
            'username': user['username'],
            'display_name': user['display_name'],
            'profile_pic': user['profile_pic'],
            'theme': user['theme']
        }
    })

# API: Update Profile
@app.route('/api/profile', methods=['POST'])
def update_profile():
    user_id = session.get('user_id')
    if not user_id:
        return jsonify({'error': 'Unauthorized'}), 401

    data = request.get_json() or {}
    new_username = data.get('username', '').strip().lower()
    new_display_name = data.get('display_name', '').strip()
    new_theme = data.get('theme', '').strip()

    if not new_username or not new_display_name:
        return jsonify({'error': 'Username and Name cannot be empty'}), 400

    if len(new_username) < 3:
        return jsonify({'error': 'Username must be at least 3 characters long'}), 400

    valid_themes = {'pastel-blue', 'pastel-pink', 'pastel-lavender', 'pastel-mint', 'pastel-peach'}
    if new_theme and new_theme not in valid_themes:
        return jsonify({'error': 'Invalid pastel theme choice'}), 400

    conn = get_db()
    cursor = conn.cursor()

    # Check username conflicts (excluding self)
    cursor.execute('SELECT id FROM users WHERE username = %s AND id != %s', (new_username, user_id))
    if cursor.fetchone():
        conn.close()
        return jsonify({'error': 'Username is already taken'}), 400

    # Fetch existing theme if new_theme is empty
    if not new_theme:
        cursor.execute('SELECT theme FROM users WHERE id = %s', (user_id,))
        existing = cursor.fetchone()
        new_theme = existing['theme'] if existing else 'pastel-blue'

    try:
        cursor.execute(
            'UPDATE users SET username = %s, display_name = %s, theme = %s WHERE id = %s',
            (new_username, new_display_name, new_theme, user_id)
        )
        conn.commit()
        conn.close()
        
        return jsonify({
            'success': True,
            'user': {
                'id': user_id,
                'username': new_username,
                'display_name': new_display_name,
                'theme': new_theme
            }
        })
    except Exception as e:
        conn.close()
        return jsonify({'error': 'Failed to update profile'}), 500

# API: Upload Profile Picture
@app.route('/api/profile/avatar', methods=['POST'])
def upload_avatar():
    user_id = session.get('user_id')
    if not user_id:
        return jsonify({'error': 'Unauthorized'}), 401

    if 'avatar' not in request.files:
        return jsonify({'error': 'No file uploaded'}), 400

    file = request.files['avatar']
    if file.filename == '':
        return jsonify({'error': 'No file selected'}), 400

    if file and allowed_file(file.filename):
        # Create a unique filename based on user_id and timestamp
        file_ext = file.filename.rsplit('.', 1)[1].lower()
        new_filename = f"user_{user_id}_{int(time.time())}.{file_ext}"
        filepath = os.path.join(UPLOAD_FOLDER, new_filename)
        
        try:
            file.save(filepath)
            
            # Save path in user record relative to the static/ directory
            db_path = f"uploads/{new_filename}"
            
            conn = get_db()
            cursor = conn.cursor()
            cursor.execute('UPDATE users SET profile_pic = %s WHERE id = %s', (db_path, user_id))
            conn.commit()
            conn.close()
            
            return jsonify({
                'success': True,
                'profile_pic': db_path
            })
        except Exception as e:
            return jsonify({'error': 'Failed to save uploaded image'}), 500
    else:
        return jsonify({'error': 'Allowed image types are png, jpg, jpeg, gif'}), 400

# API: Get Messages
@app.route('/api/messages', methods=['GET'])
def get_messages():
    user_id = session.get('user_id')
    if not user_id:
        return jsonify({'error': 'Unauthorized'}), 401

    conn = get_db()
    cursor = conn.cursor()
    cursor.execute(
        'SELECT id, content, reply, timestamp FROM messages WHERE recipient_id = %s ORDER BY timestamp DESC',
        (user_id,)
    )
    rows = cursor.fetchall()
    conn.close()

    messages_list = []
    for r in rows:
        messages_list.append({
            'id': r['id'],
            'content': r['content'],
            'reply': r['reply'],
            'timestamp': r['timestamp']
        })

    return jsonify({'messages': messages_list})

# API: Reply to a Message
@app.route('/api/messages/<int:msg_id>/reply', methods=['POST'])
def reply_message(msg_id):
    user_id = session.get('user_id')
    if not user_id:
        return jsonify({'error': 'Unauthorized'}), 401

    data = request.get_json() or {}
    reply_content = data.get('reply', '').strip()

    if len(reply_content) > 500:
        return jsonify({'error': 'Reply exceeds 500 characters limit'}), 400

    conn = get_db()
    cursor = conn.cursor()
    
    # Check ownership
    cursor.execute('SELECT id FROM messages WHERE id = %s AND recipient_id = %s', (msg_id, user_id))
    if not cursor.fetchone():
        conn.close()
        return jsonify({'error': 'Message not found or access denied'}), 404

    try:
        cursor.execute('UPDATE messages SET reply = %s WHERE id = %s', (reply_content if reply_content else None, msg_id))
        conn.commit()
        conn.close()
        return jsonify({'success': True})
    except Exception as e:
        conn.close()
        return jsonify({'error': 'Failed to save reply'}), 500

# API: Delete Message
@app.route('/api/messages/<int:msg_id>', methods=['DELETE'])
def delete_message(msg_id):
    user_id = session.get('user_id')
    if not user_id:
        return jsonify({'error': 'Unauthorized'}), 401

    conn = get_db()
    cursor = conn.cursor()
    
    # Check ownership
    cursor.execute('SELECT id FROM messages WHERE id = %s AND recipient_id = %s', (msg_id, user_id))
    if not cursor.fetchone():
        conn.close()
        return jsonify({'error': 'Message not found or access denied'}), 404

    cursor.execute('DELETE FROM messages WHERE id = %s', (msg_id,))
    conn.commit()
    conn.close()

    return jsonify({'success': True})

# API: Get Public User Info (to display personalized theme to message sender)
@app.route('/api/user/<username>', methods=['GET'])
def get_public_user(username):
    username = username.strip().lower()
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute(
        'SELECT id, username, display_name, profile_pic, theme FROM users WHERE username = %s',
        (username,)
    )
    user = cursor.fetchone()
    
    if not user:
        conn.close()
        return jsonify({'error': 'User not found'}), 404

    # Fetch user's public QA board (only messages with answers)
    cursor.execute(
        'SELECT content, reply, timestamp FROM messages WHERE recipient_id = %s AND reply IS NOT NULL AND reply != "" ORDER BY timestamp DESC',
        (user['id'],)
    )
    rows = cursor.fetchall()
    conn.close()

    answers_list = []
    for r in rows:
        answers_list.append({
            'content': r['content'],
            'reply': r['reply'],
            'timestamp': r['timestamp']
        })

    return jsonify({
        'username': user['username'],
        'display_name': user['display_name'],
        'profile_pic': user['profile_pic'],
        'theme': user['theme'],
        'answers': answers_list
    })

# API: Send Anonymous Message
@app.route('/api/send_message', methods=['POST'])
def send_message():
    data = request.get_json() or {}
    username = data.get('username', '').strip().lower()
    content = data.get('content', '').strip()

    if not username or not content:
        return jsonify({'error': 'Recipient and message content are required'}), 400

    if len(content) > 500:
        return jsonify({'error': 'Message exceeds 500 characters limit'}), 400

    conn = get_db()
    cursor = conn.cursor()
    
    # Get user ID of recipient
    cursor.execute('SELECT id FROM users WHERE username = %s', (username,))
    user = cursor.fetchone()
    
    if not user:
        conn.close()
        return jsonify({'error': 'Recipient user not found'}), 404

    try:
        cursor.execute(
            'INSERT INTO messages (recipient_id, content) VALUES (%s, %s)',
            (user['id'], content)
        )
        conn.commit()
        conn.close()
        return jsonify({'success': True})
    except Exception as e:
        conn.close()
        return jsonify({'error': 'Failed to send message'}), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
