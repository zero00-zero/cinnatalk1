-- MySQL compatible dump
-- Generated from SQLite database.db
SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

DROP TABLE IF EXISTS `messages`;
DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `username` VARCHAR(255) UNIQUE NOT NULL,
    `password_hash` VARCHAR(255) NOT NULL,
    `display_name` VARCHAR(255) NOT NULL,
    `profile_pic` VARCHAR(255),
    `theme` VARCHAR(50) DEFAULT 'pastel-blue'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table `users`
INSERT INTO `users` (`id`, `username`, `password_hash`, `display_name`, `profile_pic`, `theme`) VALUES (1, 'tester_updated', 'scrypt:32768:8:1$AQatvQ9j0NBbgQgX$48f8dc2c0d4a912f862d37d823c4941e08f553108548c9324aebb7c5e07cf8f6bdbe9add4bb9b1d3f3ef2161fcaa5b3457073a06209dbae92ef41313c2726674', 'Updated Mascot', NULL, 'pastel-pink');
INSERT INTO `users` (`id`, `username`, `password_hash`, `display_name`, `profile_pic`, `theme`) VALUES (2, 'tester_1784199190_updated', 'scrypt:32768:8:1$BvYvoFwMMIH0pvF2$350b0b3d7c81a3957a51444b094d8f6c0b67450fc58b96465e93d7808f30b37a53fb1d9af90f740c128329741aadfd83e94637e7de35c03712e32b46cafe5e1a', 'Updated Mascot', NULL, 'pastel-pink');
INSERT INTO `users` (`id`, `username`, `password_hash`, `display_name`, `profile_pic`, `theme`) VALUES (3, 'kent01', 'scrypt:32768:8:1$o8ExWNu1PoPT2ZyU$00dd71890e7a162ae6374f894fb83939339871c93fa9b47cdf2e3e6d7cb6a871f9e85d78bc7a1c769e6d318fb2a2a2ac214c476950ec81ff68f7c29ed26afd57', 'kent', 'uploads/user_3_1784199332.png', 'pastel-blue');
INSERT INTO `users` (`id`, `username`, `password_hash`, `display_name`, `profile_pic`, `theme`) VALUES (4, 'tester_1784199850_updated', 'scrypt:32768:8:1$ZZaj9aD5IYxhdu1r$971144ed257165ebe5f042690aebccac7ebf8402daa807deb4bd601ec0d4ad244def09c2da786a01dfd742d3d6cdd2b61c8f0531c681313ce5121dd39074d822', 'Updated Mascot', NULL, 'pastel-pink');
INSERT INTO `users` (`id`, `username`, `password_hash`, `display_name`, `profile_pic`, `theme`) VALUES (5, 'kuko1', 'scrypt:32768:8:1$xxODHuWV2ns0suJ1$c85c97f1dde08bf9080369223561a7c7532e0f95ea865d8e9796b48aab10c8b9f4ef8e435f9c5fedd3f757c5424686e872dd94e7564416810c1b2245f0762a53', 'kuko1', NULL, 'pastel-blue');

CREATE TABLE `messages` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `recipient_id` INT NOT NULL,
    `content` TEXT NOT NULL,
    `reply` TEXT,
    `timestamp` DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`recipient_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table `messages`
INSERT INTO `messages` (`id`, `recipient_id`, `content`, `reply`, `timestamp`) VALUES (1, 1, 'Hello anonymous friend! Hope your day is sweet. ☁️', NULL, '2026-07-16 10:53:03');
INSERT INTO `messages` (`id`, `recipient_id`, `content`, `reply`, `timestamp`) VALUES (3, 3, 'kuko', 'saksbdxaihsai', '2026-07-16 10:59:04');
INSERT INTO `messages` (`id`, `recipient_id`, `content`, `reply`, `timestamp`) VALUES (5, 3, 'swjidcfdcksdmc', NULL, '2026-07-16 11:04:59');
INSERT INTO `messages` (`id`, `recipient_id`, `content`, `reply`, `timestamp`) VALUES (6, 3, 'qswidhjsoi', 'wdefhudijw', '2026-07-16 11:05:51');

SET FOREIGN_KEY_CHECKS = 1;