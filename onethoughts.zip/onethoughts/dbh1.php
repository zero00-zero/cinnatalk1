<?php

$server = "sql211.infinityfree.com";
$username = "if0_42424478";
$password = "11152004Satan";
$dbname = "if0_42424478_cinnatalk1";

// Create connection
$conn = new mysqli($server, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
